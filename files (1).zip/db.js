/**
 * db.js — PostgreSQL Backend Layer (Browser Simulation)
 *
 * In production, replace all DB_* functions with fetch() calls to your
 * Express/Node.js or FastAPI backend that connects to PostgreSQL.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * PRODUCTION POSTGRESQL SCHEMA
 * ─────────────────────────────────────────────────────────────────────────
 *
 * -- users table
 * CREATE TABLE users (
 *   id          SERIAL PRIMARY KEY,
 *   name        VARCHAR(120)         NOT NULL,
 *   email       VARCHAR(180) UNIQUE  NOT NULL,
 *   password    VARCHAR(255)         NOT NULL, -- bcrypt hash
 *   role        VARCHAR(20)          NOT NULL CHECK (role IN ('parent','daycare')),
 *   created_at  TIMESTAMPTZ          DEFAULT NOW()
 * );
 *
 * -- daycares table
 * CREATE TABLE daycares (
 *   id          SERIAL PRIMARY KEY,
 *   user_id     INT REFERENCES users(id) ON DELETE CASCADE,
 *   name        VARCHAR(180) NOT NULL,
 *   address     VARCHAR(255),
 *   phone       VARCHAR(30),
 *   license_no  VARCHAR(60),
 *   description TEXT,
 *   capacity    INT DEFAULT 20,
 *   hours       VARCHAR(60),
 *   rating      NUMERIC(3,1) DEFAULT 0,
 *   type        VARCHAR(30),
 *   created_at  TIMESTAMPTZ DEFAULT NOW()
 * );
 *
 * -- listings table
 * CREATE TABLE listings (
 *   id          SERIAL PRIMARY KEY,
 *   daycare_id  INT REFERENCES daycares(id) ON DELETE CASCADE,
 *   name        VARCHAR(180) NOT NULL,
 *   age_group   VARCHAR(60),
 *   slots       INT DEFAULT 0,
 *   cost        NUMERIC(8,2),
 *   type        VARCHAR(30),
 *   status      VARCHAR(20) DEFAULT 'active',
 *   created_at  TIMESTAMPTZ DEFAULT NOW()
 * );
 *
 * -- children table
 * CREATE TABLE children (
 *   id          SERIAL PRIMARY KEY,
 *   daycare_id  INT REFERENCES daycares(id) ON DELETE SET NULL,
 *   listing_id  INT REFERENCES listings(id) ON DELETE SET NULL,
 *   name        VARCHAR(120) NOT NULL,
 *   dob         DATE,
 *   parent_name VARCHAR(120),
 *   parent_email VARCHAR(180),
 *   start_date  DATE,
 *   status      VARCHAR(20) DEFAULT 'enrolled',
 *   created_at  TIMESTAMPTZ DEFAULT NOW()
 * );
 *
 * -- inquiries table
 * CREATE TABLE inquiries (
 *   id          SERIAL PRIMARY KEY,
 *   daycare_id  INT REFERENCES daycares(id) ON DELETE CASCADE,
 *   parent_id   INT REFERENCES users(id) ON DELETE SET NULL,
 *   parent_name VARCHAR(120),
 *   parent_email VARCHAR(180),
 *   message     TEXT,
 *   status      VARCHAR(20) DEFAULT 'new',
 *   created_at  TIMESTAMPTZ DEFAULT NOW()
 * );
 *
 * ─────────────────────────────────────────────────────────────────────────
 * EXAMPLE NODE.JS / EXPRESS + pg API ROUTES
 * ─────────────────────────────────────────────────────────────────────────
 *
 * const { Pool } = require('pg');
 * const pool = new Pool({ connectionString: process.env.DATABASE_URL });
 *
 * app.get('/api/daycares', async (req, res) => {
 *   const { type, age, maxCost, minRating, q } = req.query;
 *   let sql = 'SELECT d.*, COUNT(l.id) AS listing_count FROM daycares d LEFT JOIN listings l ON l.daycare_id=d.id WHERE 1=1';
 *   const params = [];
 *   if (type && type !== 'all') { params.push(type); sql += ` AND d.type=$${params.length}`; }
 *   if (minRating) { params.push(minRating); sql += ` AND d.rating>=$${params.length}`; }
 *   if (q) { params.push(`%${q}%`); sql += ` AND (d.name ILIKE $${params.length} OR d.address ILIKE $${params.length})`; }
 *   sql += ' GROUP BY d.id ORDER BY d.rating DESC';
 *   const result = await pool.query(sql, params);
 *   res.json(result.rows);
 * });
 *
 * app.post('/api/auth/signup', async (req, res) => {
 *   const { name, email, password, role } = req.body;
 *   const hash = await bcrypt.hash(password, 10);
 *   const r = await pool.query(
 *     'INSERT INTO users(name,email,password,role) VALUES($1,$2,$3,$4) RETURNING id,name,email,role',
 *     [name, email, hash, role]
 *   );
 *   const token = jwt.sign(r.rows[0], process.env.JWT_SECRET, { expiresIn: '7d' });
 *   res.json({ user: r.rows[0], token });
 * });
 *
 * ─────────────────────────────────────────────────────────────────────────
 * IN-BROWSER SIMULATED DATABASE (IndexedDB + localStorage)
 * Mirrors the exact same schema and API shape.
 * ─────────────────────────────────────────────────────────────────────────
 */

const DB = (() => {
  // ── Seed Data ──
  const SEED_DAYCARES = [
    {
      id: 1, name: 'Little Stars Daycare', address: 'Springfield, IL',
      phone: '(555) 111-2222', license_no: 'DC-2024-0001',
      description: 'A warm, nurturing environment for infants and toddlers. Fully licensed, with CPR-certified staff and a Reggio Emilia-inspired curriculum.',
      capacity: 30, hours: '7:00 AM – 6:00 PM', rating: 4.9,
      type: 'center', emoji: '🌟', color: '#FFF3E0',
      age_groups: ['Infant (0-12m)', 'Toddler (1-3y)'],
      slots: 2, cost: 1400
    },
    {
      id: 2, name: 'Creative Cubs Academy', address: 'Shelbyville, IL',
      phone: '(555) 333-4444', license_no: 'DC-2024-0002',
      description: 'Arts-integrated curriculum that sparks creativity from day one. Our preschool programme blends play-based learning with early literacy foundations.',
      capacity: 24, hours: '7:30 AM – 5:30 PM', rating: 4.8,
      type: 'center', emoji: '🎨', color: '#E8F5E9',
      age_groups: ['Toddler (1-3y)', 'Preschool (3-5y)'],
      slots: 5, cost: 1200
    },
    {
      id: 3, name: 'Rainbow Den Home Care', address: 'Capital City, IL',
      phone: '(555) 555-6666', license_no: 'DC-2024-0003',
      description: 'A cozy, licensed home daycare with a low child-to-caregiver ratio. We focus on social-emotional development and outdoor play.',
      capacity: 8, hours: '6:30 AM – 6:00 PM', rating: 4.7,
      type: 'home', emoji: '🌈', color: '#F3E8FF',
      age_groups: ['Infant (0-12m)', 'Toddler (1-3y)'],
      slots: 1, cost: 900
    },
    {
      id: 4, name: 'Sprout Montessori', address: 'Ogdenville, IL',
      phone: '(555) 777-8888', license_no: 'DC-2024-0004',
      description: 'An authentic AMI-accredited Montessori environment for ages 2.5–6 years. Mixed-age classrooms, child-led learning, and passionate guides.',
      capacity: 20, hours: '8:00 AM – 3:30 PM', rating: 4.9,
      type: 'montessori', emoji: '🌿', color: '#E0F7F4',
      age_groups: ['Toddler (1-3y)', 'Preschool (3-5y)'],
      slots: 0, cost: 1800
    },
    {
      id: 5, name: 'Sunny Patch Family Care', address: 'North Haverbrook, IL',
      phone: '(555) 999-0000', license_no: 'DC-2024-0005',
      description: 'Family-run home daycare with 15 years of experience. Structured daily routines, nutritious meals, and genuine love for every child.',
      capacity: 6, hours: '7:00 AM – 5:00 PM', rating: 4.6,
      type: 'home', emoji: '☀️', color: '#FFFDE7',
      age_groups: ['Infant (0-12m)'],
      slots: 3, cost: 850
    },
    {
      id: 6, name: 'Bright Minds Early Learning', address: 'Springfield, IL',
      phone: '(555) 234-5678', license_no: 'DC-2024-0006',
      description: 'STEM-infused early childhood education in a spacious, bright facility. Dedicated teachers with ECE degrees, live security cameras for parents.',
      capacity: 40, hours: '6:45 AM – 6:15 PM', rating: 4.7,
      type: 'center', emoji: '🔬', color: '#E3F2FD',
      age_groups: ['Toddler (1-3y)', 'Preschool (3-5y)'],
      slots: 8, cost: 1550
    },
  ];

  const SEED_LISTINGS = [
    { id: 1, daycare_id: 1, name: 'Infant Full-Day', age_group: 'Infant (0-12m)', slots: 2, cost: 1400, type: 'Center', status: 'active' },
    { id: 2, daycare_id: 1, name: 'Toddler Half-Day', age_group: 'Toddler (1-3y)', slots: 3, cost: 900, type: 'Center', status: 'active' },
    { id: 3, daycare_id: 2, name: 'Preschool Full-Day', age_group: 'Preschool (3-5y)', slots: 5, cost: 1200, type: 'Center', status: 'active' },
  ];

  const SEED_CHILDREN = [
    { id: 1, daycare_id: 1, name: 'Emma Johnson', dob: '2023-03-10', parent_name: 'Sarah Johnson', parent_email: 'sarah@example.com', start_date: '2024-01-08', status: 'enrolled', program: 'Infant Full-Day' },
    { id: 2, daycare_id: 1, name: 'Liam Smith', dob: '2022-07-22', parent_name: 'Tom Smith', parent_email: 'tom@example.com', start_date: '2024-02-01', status: 'enrolled', program: 'Toddler Half-Day' },
    { id: 3, daycare_id: 1, name: 'Ava Martinez', dob: '2021-11-05', parent_name: 'Carlos Martinez', parent_email: 'carlos@example.com', start_date: '2024-03-10', status: 'enrolled', program: 'Toddler Half-Day' },
  ];

  const SEED_INQUIRIES = [
    { id: 1, daycare_id: 1, parent_name: 'Jessica Lee', parent_email: 'jessica@example.com', message: "Hi! I'm looking for full-time infant care starting September. Do you have any spots available? My daughter will be 4 months old.", status: 'new', created_at: '2024-12-01T10:30:00', emoji: '👩' },
    { id: 2, daycare_id: 1, parent_name: 'David Kim', parent_email: 'david@example.com', message: "Interested in your toddler program. Can we schedule a tour next week?", status: 'new', created_at: '2024-12-03T14:15:00', emoji: '👨' },
    { id: 3, daycare_id: 1, parent_name: 'Priya Patel', parent_email: 'priya@example.com', message: "We just moved to the area and are looking for a nurturing home for our 2-year-old. Your reviews are wonderful!", status: 'replied', created_at: '2024-12-05T09:45:00', emoji: '👩' },
  ];

  // ── Storage helpers ──
  const get  = (k, seed) => { try { const d = localStorage.getItem(k); return d ? JSON.parse(d) : seed; } catch { return seed; } };
  const set  = (k, v)    => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

  // ── Init ──
  function init() {
    if (!localStorage.getItem('tw_daycares'))  set('tw_daycares',  SEED_DAYCARES);
    if (!localStorage.getItem('tw_listings'))  set('tw_listings',  SEED_LISTINGS);
    if (!localStorage.getItem('tw_children'))  set('tw_children',  SEED_CHILDREN);
    if (!localStorage.getItem('tw_inquiries')) set('tw_inquiries', SEED_INQUIRIES);
    if (!localStorage.getItem('tw_users'))     set('tw_users',     []);
  }

  // ── USERS ──
  function signupUser(name, email, password, role) {
    const users = get('tw_users', []);
    if (users.find(u => u.email === email)) return { error: 'Email already registered.' };
    const user = { id: Date.now(), name, email, password, role, created_at: new Date().toISOString() };
    users.push(user);
    set('tw_users', users);
    return { user: { id: user.id, name, email, role } };
  }

  function loginUser(email, password, role) {
    const users = get('tw_users', []);
    const user  = users.find(u => u.email === email && u.password === password && u.role === role);
    if (!user) return { error: 'Invalid email, password, or role.' };
    return { user: { id: user.id, name: user.name, email: user.email, role: user.role } };
  }

  // ── DAYCARES (SELECT with filters) ──
  function getDaycares({ type, age, maxCost, minRating, q } = {}) {
    let rows = get('tw_daycares', SEED_DAYCARES);
    if (type  && type  !== 'all') rows = rows.filter(d => d.type === type);
    if (age   && age   !== 'all') rows = rows.filter(d => d.age_groups.some(a => a.toLowerCase().includes(age)));
    if (maxCost)   rows = rows.filter(d => d.cost <= Number(maxCost));
    if (minRating) rows = rows.filter(d => d.rating >= Number(minRating));
    if (q) { const ql = q.toLowerCase(); rows = rows.filter(d => d.name.toLowerCase().includes(ql) || d.address.toLowerCase().includes(ql)); }
    return rows;
  }

  function getDaycareById(id) { return get('tw_daycares', SEED_DAYCARES).find(d => d.id === id); }

  // ── LISTINGS ──
  function getListings(daycareId) { return get('tw_listings', SEED_LISTINGS).filter(l => l.daycare_id === daycareId); }

  function saveListing(listing) {
    const rows = get('tw_listings', SEED_LISTINGS);
    if (listing.id) {
      const i = rows.findIndex(l => l.id === listing.id);
      if (i > -1) rows[i] = listing;
    } else {
      listing.id = Date.now();
      listing.daycare_id = 1; // current user's daycare
      rows.push(listing);
    }
    set('tw_listings', rows);
    return listing;
  }

  function deleteListing(id) {
    const rows = get('tw_listings', SEED_LISTINGS).filter(l => l.id !== id);
    set('tw_listings', rows);
  }

  // ── CHILDREN ──
  function getChildren(daycareId) { return get('tw_children', SEED_CHILDREN).filter(c => c.daycare_id === daycareId); }

  function saveChild(child) {
    const rows = get('tw_children', SEED_CHILDREN);
    child.id = Date.now(); child.daycare_id = 1; child.status = 'enrolled';
    rows.push(child);
    set('tw_children', rows);
    return child;
  }

  // ── INQUIRIES ──
  function getInquiries(daycareId) { return get('tw_inquiries', SEED_INQUIRIES).filter(i => i.daycare_id === daycareId); }

  function saveInquiry(inquiry) {
    const rows = get('tw_inquiries', SEED_INQUIRIES);
    inquiry.id = Date.now(); inquiry.status = 'new'; inquiry.created_at = new Date().toISOString();
    rows.push(inquiry);
    set('tw_inquiries', rows);
    return inquiry;
  }

  function markInquiryReplied(id) {
    const rows = get('tw_inquiries', SEED_INQUIRIES);
    const i = rows.findIndex(r => r.id === id);
    if (i > -1) rows[i].status = 'replied';
    set('tw_inquiries', rows);
  }

  init();

  return { signupUser, loginUser, getDaycares, getDaycareById, getListings, saveListing, deleteListing, getChildren, saveChild, getInquiries, saveInquiry, markInquiryReplied };
})();
